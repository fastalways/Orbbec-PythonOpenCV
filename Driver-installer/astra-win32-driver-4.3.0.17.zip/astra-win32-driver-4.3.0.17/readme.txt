Double click SensorDriver_Vx.x.x.x.exe to start driver installation.
Please reboot the computer after installation.

If driver is not correctly installed, please proceed to 'ORBBEC_Windows' folder and follow the instruction to try with manual installation.